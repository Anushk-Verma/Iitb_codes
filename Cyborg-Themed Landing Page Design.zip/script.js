(() => {
  const $ = (s, c = document) => [...c.querySelectorAll(s)];
  const one = s => document.querySelector(s);
  const calm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const rnd = (a, b) => a + Math.random() * (b - a);

  /* Mobile menu */
  const burger = one('.burger'), menu = one('#menu');
  const setMenu = open => { burger.setAttribute('aria-expanded', open); menu.classList.toggle('open', open); };
  burger.addEventListener('click', () => setMenu(burger.getAttribute('aria-expanded') !== 'true'));
  $('#menu a').forEach(a => a.addEventListener('click', () => setMenu(false)));
  addEventListener('keydown', e => e.key === 'Escape' && setMenu(false));

  /* Terminal typing in the hero */
  const typeEl = one('#type'), lines = ['sync_human --upgrade', 'link --neural --latency=3ms', 'status: ALL SYSTEMS NOMINAL'];
  if (calm) typeEl.textContent = lines[2];
  else {
    let li = 0, ch = 0, del = false;
    (function tick() {
      const t = lines[li];
      typeEl.textContent = t.slice(0, ch);
      if (!del && ch === t.length) { del = true; return setTimeout(tick, 1800); }
      if (del && ch === 0) { del = false; li = (li + 1) % lines.length; }
      ch += del ? -1 : 1;
      setTimeout(tick, del ? 25 : 70);
    })();
  }

  /* Bionic eye follows the pointer, glances around when idle */
  const iris = one('#iris'), svg = iris.ownerSVGElement;
  let tx = 0, ty = 0, x = 0, y = 0, raf = 0, lastMove = 0;
  const move = () => {
    x += (tx - x) * .12; y += (ty - y) * .12;
    iris.setAttribute('transform', `translate(${x.toFixed(1)} ${y.toFixed(1)})`);
    raf = Math.abs(tx - x) + Math.abs(ty - y) > .05 ? requestAnimationFrame(move) : 0;
  };
  const aim = (nx, ny) => { tx = nx; ty = ny; if (!raf) raf = requestAnimationFrame(move); };
  if (!calm) {
    addEventListener('pointermove', e => {
      lastMove = Date.now();
      const r = svg.getBoundingClientRect(), dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
      const d = Math.hypot(dx, dy) || 1, m = Math.min(22, d / 10);
      aim(dx / d * m, dy / d * m);
    }, { passive: true });
    setInterval(() => { if (Date.now() - lastMove > 2500) aim(rnd(-16, 16), rnd(-12, 12)); }, 2200);
    setInterval(() => {
      one('#sync').textContent = rnd(97.6, 99.4).toFixed(1);
      one('#lat').textContent = Math.round(rnd(2, 4));
      one('#temp').textContent = rnd(36.4, 36.9).toFixed(1);
    }, 1200);
  }

  /* Reveal on scroll */
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }), { threshold: .25 });
  $('.rv').forEach(el => io.observe(el));

  /* Cursor-following glow on cards */
  $('.card').forEach(c => c.addEventListener('pointermove', e => {
    const r = c.getBoundingClientRect();
    c.style.setProperty('--mx', e.clientX - r.left + 'px');
    c.style.setProperty('--my', e.clientY - r.top + 'px');
  }));

  /* Human vs cyborg slider */
  const cmp = one('.cmp');
  one('#range').addEventListener('input', e => cmp.style.setProperty('--pos', e.target.value + '%'));

  /* Protocol timeline fills as you scroll */
  const steps = one('.steps'), items = $('li', steps);
  let queued = false;
  const upd = () => {
    queued = false;
    const r = steps.getBoundingClientRect(), mid = innerHeight * .6;
    steps.style.setProperty('--fill', Math.min(100, Math.max(0, (mid - r.top) / r.height * 100)) + '%');
    items.forEach(li => li.classList.toggle('on', li.getBoundingClientRect().top < mid));
  };
  addEventListener('scroll', () => { if (!queued) { queued = true; requestAnimationFrame(upd); } }, { passive: true });
  addEventListener('resize', upd);
  upd();

  /* Count-up stats */
  const nums = $('.stats b'), show = (b, v) => (b.textContent = Math.round(v) + b.dataset.s);
  new IntersectionObserver((es, o) => es.forEach(e => {
    if (!e.isIntersecting) return;
    o.unobserve(e.target);
    nums.forEach(b => {
      const to = +b.dataset.to, t0 = performance.now();
      if (calm) return show(b, to);
      (function step(now) {
        const k = Math.min(1, (now - t0) / 1600);
        show(b, to * (1 - Math.pow(1 - k, 3)));
        if (k < 1) requestAnimationFrame(step);
      })(t0);
    });
  }), { threshold: .4 }).observe(one('.stats'));

  /* Form: validate, then print a terminal-style confirmation (no backend) */
  const form = one('#form'), out = one('#out');
  form.addEventListener('submit', e => {
    e.preventDefault();
    const n = form.n, em = form.e;
    n.setAttribute('aria-invalid', !n.value.trim());
    em.setAttribute('aria-invalid', !em.checkValidity() || !em.value);
    if (!n.value.trim() || !em.checkValidity() || !em.value) {
      out.textContent = '> ERROR: enter your name and a valid email.';
      return (n.value.trim() ? em : n).focus();
    }
    const msg = ['> TRANSMISSION RECEIVED', `> Welcome to the upgrade, ${n.value.trim()}.`, `> A technician will contact you about the ${form.a.value}.`];
    out.textContent = '';
    msg.forEach((l, i) => setTimeout(() => (out.textContent += (i ? '\n' : '') + l), calm ? 0 : i * 600));
    form.reset();
  });
})();
