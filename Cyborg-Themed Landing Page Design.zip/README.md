# AUREX — Cyborg Landing Page

A responsive, cyborg-themed landing page for a fictional augmentation brand, built for Techfest IIT Bombay.
Pure HTML, CSS and vanilla JavaScript: no build step, no dependencies.

## Run locally
Open `index.html` in any modern browser.

## Highlights
- Bionic eye (SVG) that follows the cursor, with live HUD readouts
- Glitch headline, terminal typing, scanline and grid backdrop
- Human vs. cyborg comparison slider (mouse, touch and keyboard)
- Scroll-linked protocol timeline, count-up stats, cursor-glow cards
- Validated contact form with terminal-style confirmation
- Responsive down to 320px; respects `prefers-reduced-motion`

## Deploy (GitHub Pages)
Settings → Pages → Deploy from branch → `main` / root.
